import React from 'react';
import AliceCarousel from 'react-alice-carousel';
import HomeSectionCard from '../HomeSectionCard/HomeSectionCard';
import ArrowLeftIcon from '@mui/icons-material/ArrowLeft';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';

const HomeSectionCarousel = () => {
    const responsive = {
        0: { items: 1 },
        720: { items: 2 },
        1024: { items: 4 },
    };
    const items = Array(8).fill(<HomeSectionCard />); // Replace with actual dynamic items

    return (
        <div className="px-6 lg:px-10 py-10 bg-gray-50">
            <h2 className="text-xl lg:text-2xl font-semibold mb-5 text-center">Featured Products</h2>
            <div className="relative">
                <AliceCarousel
                    items={items}
                    infinite
                    responsive={responsive}
                    disableDotsControls
                    renderPrevButton={() => (
                        <button
                            className="absolute left-0 top-1/2 transform -translate-y-1/2 p-2 bg-gray-100 hover:bg-gray-300 rounded-full shadow-lg transition"
                            style={{ zIndex: 10 }}
                        >
                            <ArrowLeftIcon />
                        </button>
                    )}
                    renderNextButton={() => (
                        <button
                            className="absolute right-0 top-1/2 transform -translate-y-1/2 p-2 bg-gray-100 hover:bg-gray-300 rounded-full shadow-lg transition"
                            style={{ zIndex: 10 }}
                        >
                            <ArrowRightIcon />
                        </button>
                    )}
                />
            </div>
        </div>
    );
};

export default HomeSectionCarousel;
